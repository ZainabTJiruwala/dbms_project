import random

def generate_patient(patient_id,name,age,gender,blood_group):

    mutations=[]

    for i in range(5):

        mutations.append({
            "chr": random.choice(["1","2","3","17"]),
            "pos": random.randint(1000,9999),
            "ref": random.choice(["A","T","C","G"]),
            "alt": random.choice(["A","T","C","G"])
        })

    risk=random.choice(
        ["Low","Medium","High"]
    )

    return {

        "patient_id":patient_id,

        "patient_name":name,

        "age":age,

        "gender":gender,

        "blood_group":blood_group,

        "disease_risk":risk,

        "mutations":mutations
    }