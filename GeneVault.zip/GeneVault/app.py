# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║   GENEVAULT · GENOMIC DATA CONSOLE                                          ║
# ║   Full-Stack Patient Registry · MongoDB Atlas · Premium Dark UI             ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

import streamlit as st
from pymongo import MongoClient
from datetime import datetime, timedelta
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import re
import io

# ─────────────────────────────────────────────────────────────────────────────
#  PAGE CONFIG  (must be first Streamlit call)
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="GeneVault · Genomic Console",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────────────────────────────────────────
#  PREMIUM GLOBAL CSS  — dark void · neon cyan/purple · glassmorphism
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
/* ── FONTS ── */
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;900&family=Rajdhani:wght@300;400;500;600;700&family=JetBrains+Mono:wght@300;400;500;600&display=swap');

/* ── ROOT TOKENS ── */
:root {
  --void:    #010306;
  --deep:    #04080f;
  --surface: rgba(8,20,42,0.72);
  --glass:   rgba(4,12,28,0.85);
  --cyan:    #00d2ff;
  --cyan-s:  rgba(0,210,255,0.10);
  --purple:  #8250ff;
  --purple2: #a87aff;
  --magenta: #e040fb;
  --green:   #00ff9d;
  --red:     #ff3d5a;
  --amber:   #ffb300;
  --t1:      #dde8f5;
  --t2:      #7a9abf;
  --t3:      #3a5470;
  --border:  rgba(0,210,255,0.14);
  --border2: rgba(0,210,255,0.26);
  --disp:    'Orbitron', monospace;
  --body:    'Rajdhani', sans-serif;
  --mono:    'JetBrains Mono', monospace;
}

/* ── BASE ── */
html, body, [class*="css"], [class*="st-"] {
  font-family: var(--body) !important;
  color: var(--t1) !important;
}

.stApp {
  background: linear-gradient(135deg, #010306 0%, #040811 50%, #020509 100%) !important;
  min-height: 100vh;
}

/* Animated particle-like background */
.stApp::before {
  content: '';
  position: fixed;
  inset: 0;
  background:
    radial-gradient(ellipse 80% 50% at 20% 40%, rgba(0,210,255,0.04) 0%, transparent 60%),
    radial-gradient(ellipse 60% 40% at 80% 70%, rgba(130,80,255,0.05) 0%, transparent 60%),
    radial-gradient(ellipse 40% 30% at 50% 10%, rgba(224,64,251,0.03) 0%, transparent 50%);
  pointer-events: none;
  z-index: 0;
}

/* ── SIDEBAR ── */
[data-testid="stSidebar"] {
  background: linear-gradient(180deg, rgba(2,6,18,0.98) 0%, rgba(5,12,28,0.98) 100%) !important;
  border-right: 1px solid var(--border) !important;
  box-shadow: 4px 0 40px rgba(0,210,255,0.04) !important;
}

[data-testid="stSidebar"]::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 2px;
  background: linear-gradient(90deg, transparent 0%, var(--cyan) 40%, var(--purple) 70%, transparent 100%);
  opacity: 0.8;
}

/* ── SIDEBAR NAV RADIO ── */
div[data-testid="stSidebar"] .stRadio > div { gap: 3px !important; }

div[data-testid="stSidebar"] .stRadio label {
  display: flex !important;
  align-items: center !important;
  padding: 11px 16px !important;
  margin: 1px 0 !important;
  border-radius: 10px !important;
  border: 1px solid transparent !important;
  cursor: pointer !important;
  font-size: 14px !important;
  font-weight: 500 !important;
  color: var(--t2) !important;
  transition: all 0.2s ease !important;
  letter-spacing: 0.3px !important;
}

div[data-testid="stSidebar"] .stRadio label:hover {
  background: var(--cyan-s) !important;
  border-color: var(--border) !important;
  color: var(--cyan) !important;
}

div[data-testid="stSidebar"] .stRadio label:has(input:checked) {
  background: rgba(0,210,255,0.10) !important;
  border-left: 3px solid var(--cyan) !important;
  border-color: rgba(0,210,255,0.22) !important;
  color: var(--cyan) !important;
  box-shadow: inset 0 0 20px rgba(0,210,255,0.04) !important;
}

/* Hide radio circles */
div[data-testid="stSidebar"] .stRadio [type="radio"] { display: none !important; }

/* ── HEADINGS ── */
h1, h2, h3, h4 {
  font-family: var(--disp) !important;
  font-weight: 600 !important;
}

h1 {
  background: linear-gradient(135deg, #dde8f5, #00d2ff) !important;
  -webkit-background-clip: text !important;
  -webkit-text-fill-color: transparent !important;
  font-size: 1.6rem !important;
  letter-spacing: 3px !important;
}

h2 { color: var(--t1) !important; font-size: 1.1rem !important; letter-spacing: 2px !important; }
h3 { color: var(--t2) !important; font-size: 0.95rem !important; letter-spacing: 1.5px !important; }

/* ── BUTTONS ── */
.stButton > button {
  background: linear-gradient(135deg, rgba(0,210,255,0.12), rgba(130,80,255,0.12)) !important;
  border: 1px solid var(--cyan) !important;
  border-radius: 8px !important;
  color: var(--cyan) !important;
  font-family: var(--disp) !important;
  font-size: 11px !important;
  font-weight: 600 !important;
  letter-spacing: 2.5px !important;
  padding: 10px 20px !important;
  text-transform: uppercase !important;
  transition: all 0.22s ease !important;
  width: 100% !important;
  position: relative !important;
  overflow: hidden !important;
}

.stButton > button::before {
  content: '';
  position: absolute;
  top: -50%; left: -60%;
  width: 50%; height: 200%;
  background: linear-gradient(105deg, transparent, rgba(255,255,255,0.07), transparent);
  transition: left 0.4s;
}

.stButton > button:hover {
  background: linear-gradient(135deg, rgba(0,210,255,0.28), rgba(130,80,255,0.28)) !important;
  box-shadow: 0 0 28px rgba(0,210,255,0.28) !important;
  transform: translateY(-1px) !important;
  color: #ffffff !important;
}

.stButton > button:hover::before { left: 140% !important; }

.stButton > button:active { transform: scale(0.98) translateY(0px) !important; }

/* ── INPUTS ── */
.stTextInput > div > div > input,
.stNumberInput > div > div > input,
.stTextArea > div > div > textarea,
.stSelectbox > div > div {
  background: rgba(4,12,28,0.88) !important;
  border: 1px solid var(--border) !important;
  border-radius: 8px !important;
  color: var(--t1) !important;
  font-family: var(--body) !important;
  font-size: 14px !important;
  transition: border-color 0.2s, box-shadow 0.2s !important;
}

.stTextInput > div > div > input:focus,
.stNumberInput > div > div > input:focus,
.stTextArea > div > div > textarea:focus {
  border-color: var(--cyan) !important;
  box-shadow: 0 0 0 3px rgba(0,210,255,0.10) !important;
  outline: none !important;
}

/* Labels */
.stTextInput label, .stNumberInput label, .stSelectbox label,
.stTextArea label, .stRadio label span, .stCheckbox label span {
  font-family: var(--mono) !important;
  font-size: 10px !important;
  font-weight: 600 !important;
  color: var(--t2) !important;
  letter-spacing: 2px !important;
  text-transform: uppercase !important;
}

/* ── METRIC CARDS ── */
[data-testid="metric-container"] {
  background: linear-gradient(135deg, rgba(8,20,42,0.75), rgba(4,12,28,0.85)) !important;
  border: 1px solid var(--border) !important;
  border-radius: 14px !important;
  padding: 20px !important;
  transition: border-color 0.2s, transform 0.2s !important;
  position: relative !important;
  overflow: hidden !important;
}

[data-testid="metric-container"]::after {
  content: '';
  position: absolute;
  top: -20px; right: -20px;
  width: 80px; height: 80px;
  background: radial-gradient(circle, rgba(0,210,255,0.07), transparent 70%);
  pointer-events: none;
}

[data-testid="metric-container"]:hover {
  border-color: var(--border2) !important;
  transform: translateY(-2px) !important;
}

[data-testid="stMetricValue"] {
  font-family: var(--disp) !important;
  font-size: 2.1rem !important;
  font-weight: 700 !important;
  color: var(--cyan) !important;
  letter-spacing: 1px !important;
}

[data-testid="stMetricLabel"] {
  font-family: var(--mono) !important;
  font-size: 10px !important;
  color: var(--t3) !important;
  letter-spacing: 2.5px !important;
  text-transform: uppercase !important;
}

[data-testid="stMetricDelta"] { font-family: var(--mono) !important; font-size: 11px !important; }

/* ── TABS ── */
.stTabs [data-baseweb="tab-list"] {
  background: rgba(4,12,28,0.7) !important;
  border-bottom: 1px solid var(--border) !important;
  border-radius: 12px 12px 0 0 !important;
  padding: 0 8px !important;
  gap: 0 !important;
}

.stTabs [data-baseweb="tab"] {
  font-family: var(--disp) !important;
  font-size: 10px !important;
  font-weight: 600 !important;
  letter-spacing: 2px !important;
  padding: 13px 24px !important;
  color: var(--t3) !important;
  border-bottom: 2px solid transparent !important;
  transition: all 0.2s !important;
}

.stTabs [data-baseweb="tab"]:hover { color: var(--t2) !important; }
.stTabs [aria-selected="true"] {
  color: var(--cyan) !important;
  border-bottom: 2px solid var(--cyan) !important;
  background: rgba(0,210,255,0.06) !important;
}

/* ── DATAFRAME ── */
[data-testid="stDataFrame"] {
  background: rgba(4,12,28,0.7) !important;
  border: 1px solid var(--border) !important;
  border-radius: 12px !important;
  overflow: hidden !important;
}

/* ── ALERTS ── */
.stSuccess > div, [data-testid="stSuccess"] {
  background: rgba(0,255,157,0.07) !important;
  border: 1px solid rgba(0,255,157,0.25) !important;
  border-radius: 9px !important;
  color: var(--green) !important;
}

.stError > div, [data-testid="stError"] {
  background: rgba(255,61,90,0.07) !important;
  border: 1px solid rgba(255,61,90,0.25) !important;
  border-radius: 9px !important;
  color: var(--red) !important;
}

.stWarning > div, [data-testid="stWarning"] {
  background: rgba(255,179,0,0.07) !important;
  border: 1px solid rgba(255,179,0,0.25) !important;
  border-radius: 9px !important;
}

.stInfo > div, [data-testid="stInfo"] {
  background: rgba(0,210,255,0.07) !important;
  border: 1px solid rgba(0,210,255,0.2) !important;
  border-radius: 9px !important;
}

/* ── EXPANDER ── */
[data-testid="stExpander"] {
  background: rgba(8,20,42,0.6) !important;
  border: 1px solid var(--border) !important;
  border-radius: 10px !important;
  overflow: hidden !important;
}

[data-testid="stExpander"] summary {
  font-family: var(--body) !important;
  font-size: 14px !important;
  font-weight: 600 !important;
  color: var(--t1) !important;
  padding: 12px 16px !important;
}

/* ── FORM SUBMIT BUTTON ── */
[data-testid="stFormSubmitButton"] > button {
  background: linear-gradient(135deg, rgba(0,210,255,0.15), rgba(130,80,255,0.15)) !important;
  border: 1px solid var(--cyan) !important;
  color: var(--cyan) !important;
  font-family: var(--disp) !important;
  font-size: 11px !important;
  letter-spacing: 3px !important;
  padding: 12px 24px !important;
  border-radius: 8px !important;
  width: 100% !important;
}

[data-testid="stFormSubmitButton"] > button:hover {
  background: linear-gradient(135deg, rgba(0,210,255,0.3), rgba(130,80,255,0.3)) !important;
  box-shadow: 0 0 28px rgba(0,210,255,0.3) !important;
  color: #fff !important;
}

/* ── SCROLLBAR ── */
::-webkit-scrollbar { width: 5px; height: 5px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: rgba(0,210,255,0.25); border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: rgba(0,210,255,0.45); }

/* ── HR ── */
hr { border-color: var(--border) !important; margin: 1.5rem 0 !important; }

/* ── CHECKBOX ── */
.stCheckbox label span { font-size: 13px !important; color: var(--t1) !important; text-transform: none !important; letter-spacing: 0 !important; }

/* ── DOWNLOAD BUTTON ── */
[data-testid="stDownloadButton"] > button {
  background: linear-gradient(135deg, rgba(0,255,157,0.10), rgba(0,210,255,0.10)) !important;
  border: 1px solid var(--green) !important;
  color: var(--green) !important;
  font-family: var(--disp) !important;
  font-size: 11px !important;
  letter-spacing: 2px !important;
  border-radius: 8px !important;
  width: 100% !important;
}

[data-testid="stDownloadButton"] > button:hover {
  box-shadow: 0 0 24px rgba(0,255,157,0.25) !important;
  color: #fff !important;
}

/* ── PLOTLY CHART CONTAINER ── */
[data-testid="stPlotlyChart"] {
  border-radius: 12px;
  overflow: hidden;
}

/* ── SELECTBOX ── */
.stSelectbox [data-baseweb="select"] > div {
  background: rgba(4,12,28,0.88) !important;
  border: 1px solid var(--border) !important;
  color: var(--t1) !important;
}

/* ── NUMBER INPUT ── */
.stNumberInput button { background: transparent !important; border-color: var(--border) !important; color: var(--t2) !important; }

/* ── COLUMNS GAP ── */
[data-testid="column"] { padding: 0 6px !important; }
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
#  PLOTLY DARK THEME CONFIG
# ─────────────────────────────────────────────────────────────────────────────
PLOTLY_LAYOUT = dict(
    paper_bgcolor="rgba(4,12,28,0.0)",
    plot_bgcolor="rgba(4,12,28,0.0)",
    font=dict(family="Rajdhani", color="#7a9abf", size=12),
    margin=dict(l=20, r=20, t=30, b=20),
    xaxis=dict(gridcolor="rgba(0,210,255,0.07)", color="#3a5470", showline=False, zeroline=False),
    yaxis=dict(gridcolor="rgba(0,210,255,0.07)", color="#3a5470", showline=False, zeroline=False),
    legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor="rgba(0,210,255,0.1)", font=dict(color="#7a9abf", size=11)),
    hoverlabel=dict(bgcolor="rgba(4,12,28,0.95)", bordercolor="rgba(0,210,255,0.3)", font=dict(color="#dde8f5", family="JetBrains Mono")),
)

NEON_COLORS = ["#00d2ff", "#8250ff", "#e040fb", "#00ff9d", "#ffb300", "#ff3d5a", "#a87aff", "#00f0ff"]

# ─────────────────────────────────────────────────────────────────────────────
#  MONGODB CONNECTION
# ─────────────────────────────────────────────────────────────────────────────
@st.cache_resource(show_spinner=False)
def get_client():
    try:
        uri = "mongodb+srv://GeneVault:GeneVault%40123@geneproject.drul91o.mongodb.net/?appName=GeneProject"
        client = MongoClient(uri, serverSelectionTimeoutMS=8000)
        client.admin.command("ping")
        return client, None
    except Exception as e:
        return None, str(e)

def get_collection():
    client, err = get_client()
    if client is None:
        return None, err
    return client["GeneVaultDB"]["patients"], None

col, conn_err = get_collection()
connected = col is not None

# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────────────────────
def validate_email(e): 
    if not e:
        return False
    return bool(re.match(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$", e))

def validate_phone(p): 
    if not p:
        return False
    return bool(re.match(r"^\+?[\d\s\-()\/.]{10,15}$", p))

def generate_id():
    if col is None: 
        return "GV000000001"
    n = col.count_documents({})
    return f"GV{datetime.now().strftime('%Y%m')}{str(n+1).zfill(5)}"

def page_header(icon, title, subtitle):
    st.markdown(f"""
    <div style="background:linear-gradient(135deg,rgba(0,210,255,0.05),rgba(130,80,255,0.09));border:1px solid rgba(0,210,255,0.16);border-radius:16px;padding:22px 28px;margin-bottom:28px;display:flex;align-items:center;gap:18px;position:relative;overflow:hidden;">
      <div style="position:absolute;top:-30px;right:-30px;width:120px;height:120px;background:radial-gradient(circle,rgba(130,80,255,0.12),transparent 70%);pointer-events:none;"></div>
      <span style="font-size:2.2rem;filter:drop-shadow(0 0 8px rgba(0,210,255,0.4));">{icon}</span>
      <div>
        <div style="font-family:'Orbitron',monospace;font-size:1.4rem;font-weight:700;background:linear-gradient(135deg,#dde8f5,#00d2ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;letter-spacing:3px;">{title}</div>
        <div style="color:#7a9abf;font-size:13px;margin-top:4px;">{subtitle}</div>
      </div>
    </div>
    """, unsafe_allow_html=True)

def section_title(text, icon=""):
    st.markdown(f"""
    <div style="display:flex;align-items:center;gap:10px;margin:4px 0 16px 0;">
      <div style="width:3px;height:18px;background:linear-gradient(180deg,var(--cyan,#00d2ff),rgba(0,210,255,0.2));border-radius:2px;flex-shrink:0;"></div>
      <span style="font-family:'Orbitron',monospace;font-size:11px;font-weight:600;color:#7a9abf;letter-spacing:2.5px;text-transform:uppercase;">{icon} {text}</span>
    </div>
    """, unsafe_allow_html=True)

def glass_box(html_content):
    st.markdown(f"""
    <div style="background:rgba(8,20,42,0.65);border:1px solid rgba(0,210,255,0.14);border-radius:14px;padding:22px;margin-bottom:16px;">
      {html_content}
    </div>
    """, unsafe_allow_html=True)

def badge(text, color="#00d2ff", bg="rgba(0,210,255,0.12)"):
    return f'<span style="background:{bg};border:1px solid {color}44;border-radius:20px;padding:3px 11px;font-family:\'JetBrains Mono\',monospace;font-size:11px;color:{color};font-weight:500;">{text}</span>'

def patient_detail_card(p):
    bg_color = badge(p.get("blood_group","—"), "#e040fb", "rgba(224,64,251,0.12)")
    gcolor = "#00d2ff" if str(p.get("gender","")).lower()=="male" else "#e040fb"
    gbg = "rgba(0,210,255,0.1)" if str(p.get("gender","")).lower()=="male" else "rgba(224,64,251,0.1)"
    gen_badge = badge(p.get("gender","—"), gcolor, gbg)
    id_badge = badge(p.get("patient_id","—"), "#a87aff", "rgba(130,80,255,0.12)")
    st.markdown(f"""
    <div style="background:rgba(4,12,28,0.85);border:1px solid rgba(0,210,255,0.16);border-radius:12px;padding:20px 22px;margin-bottom:14px;position:relative;overflow:hidden;">
      <div style="position:absolute;left:0;top:0;bottom:0;width:3px;background:linear-gradient(180deg,#00d2ff,#8250ff);"></div>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:8px;">
        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
          <span style="font-size:16px;font-weight:600;color:#dde8f5;">{p.get("patient_name","—")}</span>
          {id_badge}
        </div>
        {bg_color}
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px 28px;">
        <div style="font-size:13px;color:#7a9abf;">Age: <span style="color:#dde8f5;font-weight:500;">{p.get("age","—")}</span></div>
        <div style="font-size:13px;color:#7a9abf;">Gender: {gen_badge}</div>
        <div style="font-size:13px;color:#7a9abf;">Contact: <span style="color:#dde8f5;font-weight:500;">{p.get("contact_number","—")}</span></div>
        <div style="font-size:13px;color:#7a9abf;">Email: <span style="color:#dde8f5;">{p.get("email","—")}</span></div>
        <div style="font-size:13px;color:#7a9abf;">Registered: <span style="color:#7a9abf;font-family:'JetBrains Mono',monospace;font-size:11px;">{p.get("registration_date","—")}</span></div>
        {f'<div style="font-size:13px;color:#7a9abf;">Address: <span style="color:#dde8f5;">{p.get("address","—")}</span></div>' if p.get("address") else ""}
      </div>
    </div>
    """, unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
#  SIDEBAR
# ─────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    # Logo
    st.markdown("""
    <div style="text-align:center;padding:26px 0 22px;border-bottom:1px solid rgba(0,210,255,0.1);margin-bottom:18px;">
      <div style="font-size:3rem;margin-bottom:10px;filter:drop-shadow(0 0 14px rgba(0,210,255,0.55));animation:none;">🧬</div>
      <div style="font-family:'Orbitron',monospace;font-size:1.4rem;font-weight:900;background:linear-gradient(90deg,#00d2ff,#8250ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;letter-spacing:4px;">GENEVAULT</div>
      <div style="font-size:9px;color:#3a5470;letter-spacing:3.5px;text-transform:uppercase;margin-top:5px;">Genomic Data Console</div>
    </div>
    """, unsafe_allow_html=True)

    nav_options = [
        "🏠  Dashboard",
        "➕  Register Patient",
        "🔍  Search Patient",
        "✏️  Update Patient",
        "🗑️  Delete Patient",
        "📋  View Records",
        "📤  Export Data",
    ]
    selected = st.radio("", nav_options, label_visibility="collapsed")

    # DB Status
    st.markdown("<div style='height:14px;'></div>", unsafe_allow_html=True)
    if connected:
        st.markdown("""
        <div style="background:rgba(0,255,157,0.06);border:1px solid rgba(0,255,157,0.2);border-radius:10px;padding:11px 14px;margin-top:8px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="width:7px;height:7px;border-radius:50%;background:#00ff9d;box-shadow:0 0 8px #00ff9d;flex-shrink:0;"></div>
            <span style="font-family:'JetBrains Mono',monospace;font-size:10px;color:#00ff9d;letter-spacing:1px;">ATLAS CONNECTED</span>
          </div>
          <div style="font-size:10px;color:#3a5470;margin-top:5px;font-family:'JetBrains Mono',monospace;">GeneVaultDB · patients</div>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div style="background:rgba(255,61,90,0.06);border:1px solid rgba(255,61,90,0.22);border-radius:10px;padding:11px 14px;margin-top:8px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="width:7px;height:7px;border-radius:50%;background:#ff3d5a;box-shadow:0 0 8px #ff3d5a;flex-shrink:0;"></div>
            <span style="font-family:'JetBrains Mono',monospace;font-size:10px;color:#ff3d5a;letter-spacing:1px;">CONNECTION ERROR</span>
          </div>
          <div style="font-size:9px;color:#3a5470;margin-top:4px;font-family:'JetBrains Mono',monospace;">{(conn_err or "")[:55]}</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<div style='margin-top:20px;padding-top:14px;border-top:1px solid rgba(0,210,255,0.07);'></div>", unsafe_allow_html=True)
    st.markdown(f"<div style='font-size:9px;color:#3a5470;text-align:center;font-family:JetBrains Mono,monospace;letter-spacing:1px;'>© 2025 GENEVAULT · MEMBER 1 MODULE<br>{datetime.now().strftime('%d %b %Y · %H:%M')}</div>", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
#  GATE: stop if not connected
# ─────────────────────────────────────────────────────────────────────────────
if not connected:
    st.error(f"❌ MongoDB connection failed: {conn_err}")
    st.info("Check your connection string and ensure your IP is whitelisted in Atlas.")
    st.stop()

# ─────────────────────────────────────────────────────────────────────────────
#  PAGE: DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────
if selected == nav_options[0]:
    page_header("🏠", "Genomic Data Console", "Patient Registry · Sample Inventory · Variant Storage")

    total = col.count_documents({})
    today = datetime.now().strftime("%Y-%m-%d")
    new_today = col.count_documents({"registration_date": today})
    male_n = col.count_documents({"gender": {"$regex": "^male$", "$options": "i"}})
    female_n = col.count_documents({"gender": {"$regex": "^female$", "$options": "i"}})

    # ── Metrics Row 1
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("👥 Total Patients", f"{total:,}")
    c2.metric("🧬 Total Samples", f"{total:,}")
    c3.metric("✨ New Today", new_today)
    c4.metric("🔬 Genetic Variants", "0")

    st.markdown("---")

    # ── Charts
    cc1, cc2, cc3 = st.columns(3)

    # Blood Group Bar
    with cc1:
        section_title("Blood Group Distribution", "🩸")
        bg_pipeline = list(col.aggregate([{"$group": {"_id": "$blood_group", "count": {"$sum": 1}}},
                                           {"$sort": {"_id": 1}}]))
        if bg_pipeline:
            df_bg = pd.DataFrame(bg_pipeline).rename(columns={"_id": "Blood Group", "count": "Count"})
            fig_bg = px.bar(df_bg, x="Blood Group", y="Count",
                            color="Blood Group",
                            color_discrete_sequence=NEON_COLORS,
                            text="Count")
            fig_bg.update_traces(marker_line_width=0, textposition="outside",
                                  textfont=dict(color="#dde8f5", size=11))
            fig_bg.update_layout(**PLOTLY_LAYOUT, height=240, showlegend=False,
                                  bargap=0.3)
            st.plotly_chart(fig_bg, use_container_width=True)
        else:
            st.info("No data yet")

    # Gender Donut
    with cc2:
        section_title("Gender Distribution", "⚧")
        other_n = total - male_n - female_n
        if total > 0:
            fig_g = go.Figure(go.Pie(
                labels=["Male", "Female", "Other"],
                values=[male_n, female_n, other_n],
                hole=0.58,
                marker=dict(colors=["#00d2ff", "#e040fb", "#ffb300"],
                            line=dict(color="#010306", width=2)),
                textinfo="label+percent",
                textfont=dict(family="Rajdhani", size=12, color="#dde8f5"),
                hovertemplate="<b>%{label}</b><br>Count: %{value}<extra></extra>",
            ))
            fig_g.update_layout(**PLOTLY_LAYOUT, height=240, showlegend=False)
            st.plotly_chart(fig_g, use_container_width=True)
        else:
            st.info("No data yet")

    # Registrations last 7 days
    with cc3:
        section_title("Registrations · 7 Days", "📅")
        labels, counts = [], []
        for i in range(6, -1, -1):
            d = (datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d")
            labels.append(d[5:])
            counts.append(col.count_documents({"registration_date": d}))
        fig_r = go.Figure()
        fig_r.add_trace(go.Scatter(
            x=labels, y=counts, mode="lines+markers",
            line=dict(color="#00d2ff", width=2.5, shape="spline", smoothing=1.2),
            marker=dict(color="#00d2ff", size=7, line=dict(color="#010306", width=1.5)),
            fill="tozeroy",
            fillcolor="rgba(0,210,255,0.07)",
            hovertemplate="<b>%{x}</b><br>%{y} registrations<extra></extra>",
        ))
        fig_r.update_layout(**PLOTLY_LAYOUT, height=240, showlegend=False)
        st.plotly_chart(fig_r, use_container_width=True)

    st.markdown("---")

    # ── Recent Patients Table
    section_title("Recent Patient Registrations", "📋")
    recent = list(col.find({}, {"_id": 0}).sort("registration_timestamp", -1).limit(10))
    if recent:
        rows = []
        for r in recent:
            rows.append({
                "Patient ID": r.get("patient_id", ""),
                "Name": r.get("patient_name", ""),
                "Age": r.get("age", ""),
                "Gender": r.get("gender", ""),
                "Blood Group": r.get("blood_group", ""),
                "Registered": r.get("registration_date", "")
            })
        df_show = pd.DataFrame(rows)
        st.dataframe(df_show, use_container_width=True, hide_index=True)
    else:
        st.info("No patients registered yet.")

    st.markdown("---")
    section_title("Gender Statistics", "📊")
    s1, s2, s3 = st.columns(3)
    s1.metric("♂ Male", male_n, delta=None)
    s2.metric("♀ Female", female_n, delta=None)
    s3.metric("⚧ Other", total - male_n - female_n, delta=None)

# ─────────────────────────────────────────────────────────────────────────────
#  PAGE: REGISTER PATIENT
# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────
#  PAGE: REGISTER PATIENT (FIXED - NO BUTTONS INSIDE FORM)
# ─────────────────────────────────────────────────────────────────────────────
elif selected == nav_options[1]:
    page_header("➕", "Register Patient", "Complete genomic profile · Chromosome analysis · DNA variants")

    # Initialize session state for variant count
    if 'variant_count' not in st.session_state:
        st.session_state.variant_count = 1
    
    # Add/Remove variant buttons OUTSIDE the form
    col_btn1, col_btn2, col_btn3 = st.columns([1, 1, 2])
    with col_btn1:
        if st.button("➕ Add Another Variant", key="add_variant_btn"):
            st.session_state.variant_count += 1
            st.rerun()
    with col_btn2:
        if st.button("➖ Remove Last Variant", key="remove_variant_btn") and st.session_state.variant_count > 1:
            st.session_state.variant_count -= 1
            st.rerun()

    with st.form("register_form", clear_on_submit=True):
        st.markdown("""
        <div style="margin-bottom:16px;">
          <span style="font-family:'Orbitron',monospace;font-size:11px;color:#00d2ff;letter-spacing:2px;">━━━━━━━━━━━━━━━━━━━━━━</span>
          <span style="font-family:'Orbitron',monospace;font-size:10px;color:#7a9abf;letter-spacing:2px;margin:0 12px;">PATIENT DEMOGRAPHICS</span>
          <span style="font-family:'Orbitron',monospace;font-size:11px;color:#00d2ff;letter-spacing:2px;">━━━━━━━━━━━━━━━━━━━━━━</span>
        </div>
        """, unsafe_allow_html=True)
        
        r1c1, r1c2 = st.columns(2)
        with r1c1:
            f_id = st.text_input("Patient ID", placeholder="Auto-generated if left empty", help="Leave blank for auto ID")
            f_name = st.text_input("Patient Name *", placeholder="Full legal name")
            f_age = st.number_input("Age *", min_value=0, max_value=150, value=25, step=1)
            f_dob = st.date_input("Date of Birth", value=datetime.now().date(), help="Patient's date of birth")
        with r1c2:
            f_gender = st.selectbox("Gender *", ["— Select —", "Male", "Female", "Other"])
            f_blood = st.selectbox("Blood Group *", ["— Select —","A+","A-","B+","B-","AB+","AB-","O+","O-"])
            f_phone = st.text_input("Contact Number *", placeholder="+91 98765 43210")
            f_email = st.text_input("Email Address *", placeholder="patient@example.com")

        f_addr = st.text_area("Address", placeholder="Full residential address", height=68)

        st.markdown("""
        <div style="margin:20px 0 16px;">
          <span style="font-family:'Orbitron',monospace;font-size:11px;color:#e040fb;letter-spacing:2px;">━━━━━━━━━━━━━━━━━━━━━━</span>
          <span style="font-family:'Orbitron',monospace;font-size:10px;color:#7a9abf;letter-spacing:2px;margin:0 12px;">GENOMIC SAMPLE INFORMATION</span>
          <span style="font-family:'Orbitron',monospace;font-size:11px;color:#e040fb;letter-spacing:2px;">━━━━━━━━━━━━━━━━━━━━━━</span>
        </div>
        """, unsafe_allow_html=True)
        
        g1c1, g1c2, g1c3 = st.columns(3)
        with g1c1:
            f_sample_id = st.text_input("Sample ID", placeholder="e.g., SAMP-2025-001", help="Unique sample identifier")
            f_sample_type = st.selectbox("Sample Type", ["— Select —", "Blood", "Saliva", "Tissue", "Buccal Swab", "Cultured Cells", "FFPE Tissue"])
        with g1c2:
            f_collection_date = st.date_input("Collection Date", value=datetime.now().date())
            f_lab_name = st.text_input("Laboratory Name", placeholder="e.g., Genomic Diagnostics Lab")
        with g1c3:
            f_sequencing_platform = st.selectbox("Sequencing Platform", [
                "— Select —", "Illumina NovaSeq 6000", "Illumina HiSeq X", "Oxford Nanopore", 
                "PacBio Sequel", "Ion Torrent", "BGISEQ-500", "Complete Genomics"
            ])
            f_sequencing_depth = st.text_input("Sequencing Depth (X)", placeholder="e.g., 30X, 50X, 100X")

        st.markdown("""
        <div style="margin:20px 0 16px;">
          <span style="font-family:'Orbitron',monospace;font-size:11px;color:#8250ff;letter-spacing:2px;">━━━━━━━━━━━━━━━━━━━━━━</span>
          <span style="font-family:'Orbitron',monospace;font-size:10px;color:#7a9abf;letter-spacing:2px;margin:0 12px;">CHROMOSOME ANALYSIS</span>
          <span style="font-family:'Orbitron',monospace;font-size:11px;color:#8250ff;letter-spacing:2px;">━━━━━━━━━━━━━━━━━━━━━━</span>
        </div>
        """, unsafe_allow_html=True)
        
        c1c1, c1c2, c1c3 = st.columns(3)
        with c1c1:
            f_chromosome = st.text_input("Chromosome Number", placeholder="e.g., 1, X, Y, 22", help="Affected chromosome")
            f_chromosome_region = st.text_input("Chromosome Region/Band", placeholder="e.g., 17q21.31, 1p36", help="Cytogenetic location")
        with c1c2:
            f_karyotype = st.text_input("Karyotype Result", placeholder="e.g., 46,XX; 46,XY; 47,XX,+21")
            f_ploidy = st.selectbox("Ploidy Status", ["— Select —", "Normal Diploid", "Aneuploid", "Triploid", "Tetraploid", "Mosaic"])
        with c1c3:
            f_chromosome_abnormality = st.selectbox("Chromosome Abnormality", [
                "— Select —", "None Detected", "Deletion", "Duplication", "Translocation", 
                "Inversion", "Insertion", "Aneuploidy", "Ring Chromosome", "Isochromosome"
            ])
            f_cnv_detected = st.text_area("CNV Details", placeholder="Copy Number Variations detected", height=50)

        st.markdown("""
        <div style="margin:20px 0 16px;">
          <span style="font-family:'Orbitron',monospace;font-size:11px;color:#ffb300;letter-spacing:2px;">━━━━━━━━━━━━━━━━━━━━━━</span>
          <span style="font-family:'Orbitron',monospace;font-size:10px;color:#7a9abf;letter-spacing:2px;margin:0 12px;">GENETIC VARIANTS / MUTATIONS</span>
          <span style="font-family:'Orbitron',monospace;font-size:11px;color:#ffb300;letter-spacing:2px;">━━━━━━━━━━━━━━━━━━━━━━</span>
        </div>
        """, unsafe_allow_html=True)
        
        variants_list = []
        
        for i in range(st.session_state.variant_count):
            st.markdown(f"""
            <div style="background:rgba(130,80,255,0.05);border:1px solid rgba(130,80,255,0.15);border-radius:10px;padding:15px;margin-bottom:12px;">
              <span style="font-family:'Orbitron',monospace;font-size:9px;color:#a87aff;letter-spacing:2px;">VARIANT #{i+1}</span>
            </div>
            """, unsafe_allow_html=True)
            
            v1, v2, v3 = st.columns(3)
            with v1:
                f_variant_gene = st.text_input(f"Gene Name", key=f"var_gene_{i}", placeholder="e.g., BRCA1, TP53, EGFR")
                f_variant_type = st.selectbox(f"Variant Type", 
                    ["— Select —", "SNP", "Insertion", "Deletion", "Duplication", "Inversion", "Frameshift", "Missense", "Nonsense", "Splice Site"],
                    key=f"var_type_{i}")
            with v2:
                f_variant_id = st.text_input(f"Variant ID", key=f"var_id_{i}", placeholder="rsID or custom ID")
                f_ref_allele = st.text_input(f"Reference Allele", key=f"var_ref_{i}", max_chars=20, placeholder="e.g., A, T, C, G")
            with v3:
                f_alt_allele = st.text_input(f"Alternate Allele", key=f"var_alt_{i}", max_chars=20, placeholder="e.g., G, C, T, A")
                f_mutation_position = st.text_input(f"Mutation Position", key=f"var_pos_{i}", placeholder="e.g., 43044295, chr17:43044295")
            
            v4, v5 = st.columns(2)
            with v4:
                f_zygosity = st.selectbox(f"Zygosity", ["— Select —", "Homozygous", "Heterozygous", "Hemizygous", "Unknown"], key=f"var_zyg_{i}")
            with v5:
                f_clinical_significance = st.selectbox(f"Clinical Significance", 
                    ["— Select —", "Pathogenic", "Likely Pathogenic", "Benign", "Likely Benign", "VUS", "Uncertain Significance"],
                    key=f"var_sig_{i}")
            
            v6, v7 = st.columns(2)
            with v6:
                f_protein_change = st.text_input(f"Protein Change", key=f"var_prot_{i}", placeholder="e.g., p.Gly12Val, p.Arg248Trp")
            with v7:
                f_cdna_change = st.text_input(f"cDNA Change", key=f"var_cdna_{i}", placeholder="e.g., c.34G>T, c.5243G>A")
            
            if f_variant_gene and f_variant_gene != "— Select —":
                variants_list.append({
                    "gene_name": f_variant_gene,
                    "variant_id": f_variant_id if f_variant_id else None,
                    "variant_type": f_variant_type if f_variant_type != "— Select —" else None,
                    "reference_allele": f_ref_allele if f_ref_allele else None,
                    "alternate_allele": f_alt_allele if f_alt_allele else None,
                    "mutation_position": f_mutation_position if f_mutation_position else None,
                    "zygosity": f_zygosity if f_zygosity != "— Select —" else None,
                    "clinical_significance": f_clinical_significance if f_clinical_significance != "— Select —" else None,
                    "protein_change": f_protein_change if f_protein_change else None,
                    "cdna_change": f_cdna_change if f_cdna_change else None
                })

        st.markdown("""
        <div style="margin:20px 0 16px;">
          <span style="font-family:'Orbitron',monospace;font-size:11px;color:#00ff9d;letter-spacing:2px;">━━━━━━━━━━━━━━━━━━━━━━</span>
          <span style="font-family:'Orbitron',monospace;font-size:10px;color:#7a9abf;letter-spacing:2px;margin:0 12px;">CLINICAL INTERPRETATION</span>
          <span style="font-family:'Orbitron',monospace;font-size:11px;color:#00ff9d;letter-spacing:2px;">━━━━━━━━━━━━━━━━━━━━━━</span>
        </div>
        """, unsafe_allow_html=True)
        
        ct1, ct2 = st.columns(2)
        with ct1:
            f_diagnosis = st.text_area("Primary Diagnosis", placeholder="Clinical diagnosis based on genomic findings", height=68)
            f_affected_status = st.selectbox("Affected Status", ["— Select —", "Affected", "Unaffected", "Carrier", "Unknown"])
        with ct2:
            f_family_history = st.text_area("Family History", placeholder="Relevant family medical history", height=68)
            f_ethnicity = st.text_input("Ethnicity", placeholder="Patient's ethnic background")

        st.markdown("""
        <div style="margin:20px 0 16px;">
          <span style="font-family:'Orbitron',monospace;font-size:11px;color:#ff3d5a;letter-spacing:2px;">━━━━━━━━━━━━━━━━━━━━━━</span>
          <span style="font-family:'Orbitron',monospace;font-size:10px;color:#7a9abf;letter-spacing:2px;margin:0 12px;">SYSTEM METADATA</span>
          <span style="font-family:'Orbitron',monospace;font-size:11px;color:#ff3d5a;letter-spacing:2px;">━━━━━━━━━━━━━━━━━━━━━━</span>
        </div>
        """, unsafe_allow_html=True)
        
        sys1, sys2 = st.columns(2)
        with sys1:
            f_created_by = st.text_input("Created By (Doctor/Lab)", placeholder="Clinician name or Lab ID", help="Name of the person entering this record")
            f_record_status = st.selectbox("Record Status", ["Active", "Archived", "Pending Review", "Flagged"])
        with sys2:
            f_consent_obtained = st.checkbox("Informed consent obtained for genomic testing")
            f_data_sharing = st.checkbox("Consent for data sharing (anonymized)")

        st.markdown("<div style='height:6px;'></div>", unsafe_allow_html=True)
        
        # SUBMIT BUTTON INSIDE THE FORM
        submitted = st.form_submit_button("⚡  REGISTER PATIENT WITH GENOMIC DATA", use_container_width=True)

        if submitted:
            errors = []
            if not f_name.strip():        errors.append("Patient name is required")
            if f_age <= 0:                errors.append("Valid age is required")
            if f_gender == "— Select —":  errors.append("Gender is required")
            if f_blood == "— Select —":   errors.append("Blood group is required")
            if not validate_phone(f_phone): errors.append("Valid contact number required (10-15 digits)")
            if not validate_email(f_email): errors.append("Valid email address required")
            if not f_created_by.strip():  errors.append("Created By is required")

            if errors:
                for e in errors:
                    st.error(f"❌  {e}")
            else:
                pid = f_id.strip() or generate_id()
                if col.find_one({"patient_id": pid}):
                    st.error(f"❌  Patient ID **{pid}** already exists.")
                else:
                    doc = {
                        "patient_id": pid,
                        "patient_name": f_name.strip(),
                        "age": int(f_age),
                        "date_of_birth": f_dob.strftime("%Y-%m-%d"),
                        "gender": f_gender,
                        "blood_group": f_blood,
                        "contact_number": f_phone.strip(),
                        "email": f_email.strip().lower(),
                        "address": f_addr.strip(),
                        
                        # Genomic Sample Information
                        "sample_info": {
                            "sample_id": f_sample_id.strip() if f_sample_id else None,
                            "sample_type": f_sample_type if f_sample_type != "— Select —" else None,
                            "collection_date": f_collection_date.strftime("%Y-%m-%d"),
                            "laboratory_name": f_lab_name.strip() if f_lab_name else None,
                            "sequencing_platform": f_sequencing_platform if f_sequencing_platform != "— Select —" else None,
                            "sequencing_depth": f_sequencing_depth.strip() if f_sequencing_depth else None
                        },
                        
                        # Chromosome Analysis
                        "chromosome_analysis": {
                            "chromosome": f_chromosome.strip() if f_chromosome else None,
                            "chromosome_region": f_chromosome_region.strip() if f_chromosome_region else None,
                            "karyotype": f_karyotype.strip() if f_karyotype else None,
                            "ploidy": f_ploidy if f_ploidy != "— Select —" else None,
                            "chromosome_abnormality": f_chromosome_abnormality if f_chromosome_abnormality != "— Select —" else None,
                            "cnv_details": f_cnv_detected.strip() if f_cnv_detected else None
                        },
                        
                        # Genetic Variants
                        "genetic_variants": variants_list if variants_list else [],
                        "variant_count": len(variants_list),
                        
                        # Clinical Interpretation
                        "clinical_info": {
                            "primary_diagnosis": f_diagnosis.strip() if f_diagnosis else None,
                            "affected_status": f_affected_status if f_affected_status != "— Select —" else None,
                            "family_history": f_family_history.strip() if f_family_history else None,
                            "ethnicity": f_ethnicity.strip() if f_ethnicity else None
                        },
                        
                        # System Metadata
                        "system_info": {
                            "created_by": f_created_by.strip(),
                            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "record_status": f_record_status.lower(),
                            "consent_obtained": f_consent_obtained,
                            "data_sharing_consent": f_data_sharing
                        },
                        
                        "registration_date": datetime.now().strftime("%Y-%m-%d"),
                        "registration_timestamp": datetime.now().timestamp(),
                    }
                    
                    col.insert_one(doc)
                    st.success(f"✅  Patient **{f_name.strip()}** registered with ID: `{pid}`")
                    st.balloons()
                    
                    # Show summary of genomic data entered
                    with st.expander("📊  View Genomic Summary Report", expanded=True):
                        st.markdown(f"""
                        <div style="background:rgba(0,210,255,0.05);border-radius:10px;padding:15px;">
                          <h4 style="color:#00d2ff;margin-bottom:10px;">Genomic Profile Summary</h4>
                          <p><strong>🧬 Sample ID:</strong> {f_sample_id or 'Not provided'}</p>
                          <p><strong>🔬 Sample Type:</strong> {f_sample_type if f_sample_type != '— Select —' else 'Not specified'}</p>
                          <p><strong>🧬 Sequencing Platform:</strong> {f_sequencing_platform if f_sequencing_platform != '— Select —' else 'Not specified'}</p>
                          <p><strong>📊 Chromosome Analysis:</strong> {f_chromosome or 'Not specified'} {f_chromosome_region or ''}</p>
                          <p><strong>🧬 Variants Detected:</strong> {len(variants_list)}</p>
                          <p><strong>⚕️ Primary Diagnosis:</strong> {f_diagnosis[:100] + '...' if len(f_diagnosis) > 100 else f_diagnosis or 'Not specified'}</p>
                        </div>
                        """, unsafe_allow_html=True)
                        
                        if variants_list:
                            st.markdown("### 🧬 Detected Variants")
                            df_variants = pd.DataFrame(variants_list)
                            st.dataframe(df_variants, use_container_width=True, hide_index=True)

    st.markdown("""
    <div style="margin-top:8px;text-align:center;font-size:11px;color:#3a5470;font-family:'JetBrains Mono',monospace;letter-spacing:1px;">
      ⚡ Fields marked with * are required | Add multiple variants using the buttons above
    </div>
    """, unsafe_allow_html=True)
# ─────────────────────────────────────────────────────────────────────────────
#  PAGE: SEARCH PATIENT
# ─────────────────────────────────────────────────────────────────────────────
elif selected == nav_options[2]:
    page_header("🔍", "Search Patient", "Find patient records by ID or name")

    col_a, col_b = st.columns([1,2])
    with col_a:
        search_by = st.radio("Search by", ["Patient ID", "Patient Name"], horizontal=False)
    with col_b:
        placeholder = "e.g. GV202400001" if search_by == "Patient ID" else "e.g. John Doe"
        term = st.text_input("Search Term", placeholder=placeholder, label_visibility="collapsed")

    if st.button("🔍  Search Records", use_container_width=True):
        if not term.strip():
            st.warning("⚠️  Please enter a search term.")
        else:
            if search_by == "Patient ID":
                query = {"patient_id": {"$regex": f"^{term.strip()}$", "$options": "i"}}
            else:
                query = {"patient_name": {"$regex": re.escape(term.strip()), "$options": "i"}}
            results = list(col.find(query, {"_id": 0}))
            if results:
                st.success(f"✅  Found **{len(results)}** record(s)")
                for p in results:
                    patient_detail_card(p)
            else:
                st.error(f"❌  No records found matching: **{term}**")

# ─────────────────────────────────────────────────────────────────────────────
#  PAGE: UPDATE PATIENT
# ─────────────────────────────────────────────────────────────────────────────
elif selected == nav_options[3]:
    page_header("✏️", "Update Patient", "Modify existing patient information")

    lookup_id = st.text_input("Enter Patient ID to update", placeholder="e.g. GV202400001")

    if st.button("🔍  Lookup Patient", use_container_width=True):
        st.session_state["upd_patient"] = None
        if lookup_id.strip():
            found = col.find_one({"patient_id": {"$regex": f"^{lookup_id.strip()}$", "$options": "i"}}, {"_id": 0})
            st.session_state["upd_patient"] = found
        else:
            st.warning("Enter a Patient ID first.")

    if st.session_state.get("upd_patient"):
        p = st.session_state["upd_patient"]
        st.success(f"✅  Found: **{p.get('patient_name')}** · ID: `{p.get('patient_id')}`")

        with st.form("update_form"):
            u1, u2 = st.columns(2)
            with u1:
                u_name = st.text_input("Patient Name", value=p.get("patient_name",""))
                u_age = st.number_input("Age", min_value=0, max_value=150, value=int(p.get("age",25)))
            with u2:
                u_phone = st.text_input("Contact Number", value=p.get("contact_number",""))
                u_email = st.text_input("Email", value=p.get("email",""))
            u_addr = st.text_area("Address", value=p.get("address",""), height=80)

            st.caption("ℹ️  Patient ID, Gender and Blood Group cannot be modified.")
            save = st.form_submit_button("💾  SAVE CHANGES", use_container_width=True)

            if save:
                errs = []
                if not u_name.strip():       errs.append("Name required")
                if u_age <= 0:               errs.append("Valid age required")
                if not validate_phone(u_phone): errs.append("Valid phone required")
                if not validate_email(u_email): errs.append("Valid email required")
                if errs:
                    for e in errs: st.error(f"❌  {e}")
                else:
                    col.update_one(
                        {"patient_id": p["patient_id"]},
                        {"$set": {
                            "patient_name": u_name.strip(),
                            "age": int(u_age),
                            "contact_number": u_phone.strip(),
                            "email": u_email.strip().lower(),
                            "address": u_addr.strip(),
                        }}
                    )
                    st.success("✅  Patient record updated successfully!")
                    st.session_state["upd_patient"] = None
    elif "upd_patient" in st.session_state and st.session_state["upd_patient"] is None and lookup_id.strip():
        st.error(f"❌  No patient found with ID: **{lookup_id}**")

# ─────────────────────────────────────────────────────────────────────────────
#  PAGE: DELETE PATIENT
# ─────────────────────────────────────────────────────────────────────────────
elif selected == nav_options[4]:
    page_header("🗑️", "Delete Patient", "Permanently remove patient records")

    st.warning("⚠️  This action is **irreversible**. Deleted records cannot be recovered.")
    del_id = st.text_input("Enter Patient ID to delete", placeholder="e.g. GV202400001")

    if st.button("🔍  Lookup Patient", use_container_width=True):
        st.session_state["del_patient"] = None
        if del_id.strip():
            found = col.find_one({"patient_id": {"$regex": f"^{del_id.strip()}$", "$options": "i"}}, {"_id": 0})
            st.session_state["del_patient"] = found
        else:
            st.warning("Enter a Patient ID first.")

    if st.session_state.get("del_patient"):
        p = st.session_state["del_patient"]

        st.markdown(f"""
        <div style="background:rgba(18,28,46,0.65);border:1px solid rgba(0,210,255,0.18);border-radius:12px;padding:20px 24px;margin:16px 0;">
          <div style="font-family:'Orbitron',monospace;font-size:11px;color:#ff3d5a;letter-spacing:2px;margin-bottom:12px;">PATIENT TO BE DELETED</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px 28px;">
            <div style="font-size:13px;color:#7a9abf;">ID: <span style="color:#a87aff;font-family:'JetBrains Mono',monospace;">{p.get("patient_id","—")}</span></div>
            <div style="font-size:13px;color:#7a9abf;">Name: <span style="color:#dde8f5;font-weight:600;">{p.get("patient_name","—")}</span></div>
            <div style="font-size:13px;color:#7a9abf;">Age: <span style="color:#dde8f5;">{p.get("age","—")}</span></div>
            <div style="font-size:13px;color:#7a9abf;">Blood: <span style="color:#e040fb;">{p.get("blood_group","—")}</span></div>
            <div style="font-size:13px;color:#7a9abf;">Registered: <span style="color:#3a5470;font-family:'JetBrains Mono',monospace;font-size:11px;">{p.get("registration_date","—")}</span></div>
          </div>
        </div>
        """, unsafe_allow_html=True)

        confirm = st.checkbox("✅  I confirm I want to permanently delete this patient record")
        if confirm:
            if st.button("🗑️  DELETE PERMANENTLY", use_container_width=True):
                result = col.delete_one({"patient_id": p["patient_id"]})
                if result.deleted_count:
                    st.success(f"✅  Patient **{p.get('patient_name')}** (ID: {p.get('patient_id')}) permanently deleted.")
                    st.session_state["del_patient"] = None
                    st.rerun()
                else:
                    st.error("❌  Deletion failed.")
    elif "del_patient" in st.session_state and st.session_state["del_patient"] is None and del_id.strip():
        st.error(f"❌  No patient found with ID: **{del_id}**")

# ─────────────────────────────────────────────────────────────────────────────
#  PAGE: VIEW RECORDS
# ─────────────────────────────────────────────────────────────────────────────
elif selected == nav_options[5]:
    page_header("📋", "View Records", "Browse all patient records in the database")

    filter_term = st.text_input("🔍  Filter by Patient ID or Name", placeholder="Type to search...", label_visibility="visible")

    query = {}
    if filter_term.strip():
        query["$or"] = [
            {"patient_id": {"$regex": re.escape(filter_term.strip()), "$options": "i"}},
            {"patient_name": {"$regex": re.escape(filter_term.strip()), "$options": "i"}},
        ]

    records = list(col.find(query, {"_id": 0}).sort("registration_timestamp", -1))

    if records:
        st.info(f"📊  Showing **{len(records)}** patient record(s)")
        df = pd.DataFrame(records)
        cols_show = [c for c in ["patient_id","patient_name","age","gender","blood_group","contact_number","email","registration_date"] if c in df.columns]
        df_show = df[cols_show].copy()
        df_show.columns = ["Patient ID","Name","Age","Gender","Blood Group","Contact","Email","Registered"]
        st.dataframe(
            df_show, use_container_width=True, height=520, hide_index=True,
            column_config={
                "Patient ID": st.column_config.TextColumn(width="medium"),
                "Name": st.column_config.TextColumn(width="large"),
                "Age": st.column_config.NumberColumn(width="small"),
                "Blood Group": st.column_config.TextColumn(width="small"),
                "Email": st.column_config.TextColumn(width="large"),
            }
        )
    else:
        st.info("No patient records found. Register patients to see them here.")

# ─────────────────────────────────────────────────────────────────────────────
#  PAGE: EXPORT DATA
# ─────────────────────────────────────────────────────────────────────────────
elif selected == nav_options[6]:
    page_header("📤", "Export Data", "Download patient records as CSV or JSON")

    total_rec = col.count_documents({})

    st.markdown(f"""
    <div style="background:rgba(0,210,255,0.06);border:1px solid rgba(0,210,255,0.18);border-radius:10px;padding:16px 20px;margin-bottom:22px;display:flex;align-items:center;gap:18px;">
      <div>
        <div style="font-family:'Orbitron',monospace;font-size:1.6rem;font-weight:700;color:#00d2ff;">{total_rec:,}</div>
        <div style="font-size:10px;color:#3a5470;font-family:'JetBrains Mono',monospace;letter-spacing:1.5px;margin-top:2px;">RECORDS AVAILABLE</div>
      </div>
      <div style="width:1px;background:rgba(0,210,255,0.14);height:44px;margin:0 4px;"></div>
      <div style="font-size:13px;color:#7a9abf;">All patient records will be included in the export.</div>
    </div>
    """, unsafe_allow_html=True)

    if total_rec > 0:
        records = list(col.find({}, {"_id": 0}))
        df_exp = pd.DataFrame(records)
        ts_str = datetime.now().strftime("%Y%m%d_%H%M%S")

        ec1, ec2 = st.columns(2)

        # CSV export
        csv_buf = io.StringIO()
        df_exp.to_csv(csv_buf, index=False)
        with ec1:
            st.download_button(
                label=f"⬇️  Export as CSV  ({total_rec} records)",
                data=csv_buf.getvalue(),
                file_name=f"genevault_export_{ts_str}.csv",
                mime="text/csv",
                use_container_width=True,
            )

        # JSON export
        json_data = df_exp.to_json(orient="records", indent=2)
        with ec2:
            st.download_button(
                label=f"⬇️  Export as JSON  ({total_rec} records)",
                data=json_data,
                file_name=f"genevault_export_{ts_str}.json",
                mime="application/json",
                use_container_width=True,
            )

        st.markdown("---")
        section_title("Preview Export  (first 10 rows)", "👁️")
        preview_cols = [c for c in ["patient_id","patient_name","age","gender","blood_group","registration_date"] if c in df_exp.columns]
        st.dataframe(df_exp[preview_cols].head(10), use_container_width=True, hide_index=True)

        # Export analytics
        st.markdown("---")
        section_title("Export Analytics", "📊")
        ea1, ea2, ea3 = st.columns(3)

        with ea1:
            if "blood_group" in df_exp.columns:
                bg_counts = df_exp["blood_group"].value_counts().reset_index()
                bg_counts.columns = ["blood_group", "count"]
                fig_e1 = px.pie(bg_counts,
                                names="blood_group", values="count",
                                color_discrete_sequence=NEON_COLORS, hole=0.5,
                                title="Blood Groups")
                fig_e1.update_layout(**PLOTLY_LAYOUT, height=220)
                st.plotly_chart(fig_e1, use_container_width=True)

        with ea2:
            if "gender" in df_exp.columns:
                gender_counts = df_exp["gender"].value_counts().reset_index()
                gender_counts.columns = ["gender", "count"]
                fig_e2 = px.bar(gender_counts,
                                x="gender", y="count",
                                color_discrete_sequence=["#00d2ff","#e040fb","#ffb300"])
                fig_e2.update_layout(**PLOTLY_LAYOUT, height=220, showlegend=False)
                st.plotly_chart(fig_e2, use_container_width=True)

        with ea3:
            if "age" in df_exp.columns:
                fig_e3 = px.histogram(df_exp, x="age", nbins=12,
                                      color_discrete_sequence=["#8250ff"])
                fig_e3.update_layout(**PLOTLY_LAYOUT, height=220, showlegend=False,
                                     xaxis_title="Age", yaxis_title="Count")
                st.plotly_chart(fig_e3, use_container_width=True)

    else:
        st.warning("⚠️  No records to export. Register patients first.")

# ─────────────────────────────────────────────────────────────────────────────
#  FOOTER
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("---")
st.markdown("""
<div style="text-align:center;padding:10px 0 4px;">
  <span style="font-family:'JetBrains Mono',monospace;font-size:10px;color:#3a5470;letter-spacing:2px;">
    © 2025 GENEVAULT · GENOMIC DATA MANAGEMENT PLATFORM · MEMBER 1 MODULE
  </span>
</div>
""", unsafe_allow_html=True)