from pymongo import MongoClient

uri = "mongodb+srv://GeneVault:GeneVault%40123@geneproject.drul91o.mongodb.net/?retryWrites=true&w=majority"

client = MongoClient(uri)

db = client["GeneVaultDB"]