from pymongo import MongoClient

uri = "mongodb+srv://GeneVault:GeneVault%40123@geneproject.drul91o.mongodb.net/?retryWrites=true&w=majority"

try:
    client = MongoClient(uri, serverSelectionTimeoutMS=5000)
    client.admin.command("ping")
    print("SUCCESS")
except Exception as e:
    print("ERROR:")
    print(e)